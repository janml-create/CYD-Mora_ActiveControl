/*
 * mora_controller.ino — MO-RA IV 600 standalone controller
 * Target: CYD / ESP32-2432S028R (2.8" ILI9341 320x240 + XPT2046 touch)
 *
 * Replaces the PC as the brain for the MO-RA. Drives the MO-RA IV Link
 * module's FAN and PUMP PWM inputs (it just emulates a motherboard fan
 * header), reads their tach outputs, reads coolant temp, and runs a
 * temperature-driven fan curve. Touch UI + web UI + optional MQTT.
 *
 * FAILSAFE BY DESIGN: fans and D5 pumps run 100% when the PWM line is
 * idle/floating. So if this board crashes, browns out, or is unplugged,
 * the MoRa goes to FULL COOLING, never to zero. The watchdog reboots on
 * hang. Software floors (FAN_MIN/PUMP_MIN) mean it can never command a
 * stop, and a failed temp sensor forces 100%.
 *
 * Libraries (Arduino IDE / PlatformIO):
 *   TFT_eSPI            (use the included User_Setup_CYD.h)
 *   XPT2046_Touchscreen
 *   OneWire + DallasTemperature
 *   PubSubClient        (optional MQTT)
 *   Preferences, WiFi, WebServer  (bundled with ESP32 core)
 */

#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <SPI.h>
#include <TFT_eSPI.h>
#include <XPT2046_Touchscreen.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <PubSubClient.h>
#include <esp_task_wdt.h>

// ===================== USER CONFIG =====================
const char* WIFI_SSID = "YOUR_SSID";
const char* WIFI_PASS = "YOUR_PASS";
const char* MQTT_HOST = "192.168.1.10";   // "" to disable MQTT
const int   MQTT_PORT = 1883;
const char* MQTT_ID   = "mora-controller";

#define FAN_MIN_PCT     20     // never below this (audible floor, keeps air moving)
#define PUMP_MIN_PCT    40     // NEVER let a D5 stop. Do not lower.
#define TEMP_ALARM_C    45.0f  // buzzer + force 100%
#define TEMP_SENSOR_FAIL_PCT 100  // sensor dead -> full send
// =======================================================

// ---- CYD pin map ----
// Free pins on the ESP32-2432S028R. GPIO16/17 steal the onboard RGB LED
// (green/blue) — a fair trade, nobody uses it.
#define PIN_FAN_PWM     22   // -> Link module FAN header pin 4
#define PIN_PUMP_PWM    27   // -> Link module PUMP header pin 4
#define PIN_FAN_TACH    35   // <- FAN header pin 3   (INPUT ONLY, needs ext. 10k pull-up to 3V3)
#define PIN_PUMP_TACH   16   // <- PUMP header pin 3  (internal pull-up OK)
#define PIN_TEMP_1W     17   // DS18B20 coolant sensor (4.7k pull-up to 3V3)
#define PIN_BUZZER      26   // CYD onboard speaker pin
#define PIN_BACKLIGHT   21   // CYD backlight

// LEDC (PWM) — 25 kHz is the Intel 4-wire fan spec; D5 PWM likes it too.
#define LEDC_FAN_CH     0
#define LEDC_PUMP_CH    1
#define PWM_FREQ        25000
#define PWM_RES         8      // 0..255

// ---- touch (CYD uses a separate SPI bus for XPT2046) ----
#define T_CS 33
#define T_IRQ 36
SPIClass touchSPI(VSPI);
XPT2046_Touchscreen ts(T_CS, T_IRQ);
// Raw touch range on most CYD panels; tweak if taps land off-target.
#define TS_MINX 200
#define TS_MAXX 3700
#define TS_MINY 240
#define TS_MAXY 3800

TFT_eSPI tft = TFT_eSPI();
OneWire oneWire(PIN_TEMP_1W);
DallasTemperature sensors(&oneWire);
WebServer server(80);
WiFiClient net;
PubSubClient mqtt(net);
Preferences prefs;

// ===================== STATE =====================
struct CurvePt { float t; uint8_t pct; };
// Default fan curve — 5 points, editable via web UI, saved to NVS.
CurvePt fanCurve[5] = {
  {25.0f, 20}, {30.0f, 35}, {35.0f, 55}, {40.0f, 80}, {45.0f, 100}
};
bool    autoMode    = true;
uint8_t manualFan   = 40;
uint8_t manualPump  = 60;
uint8_t pumpAutoPct = 60;   // pump % in auto (flat; D5s don't need a curve)

float   coolantC    = NAN;
bool    tempOK      = false;
uint8_t fanPct      = 100;  // boot at 100 until we know better
uint8_t pumpPct     = 100;
volatile uint32_t fanPulses = 0, pumpPulses = 0;
uint16_t fanRPM = 0, pumpRPM = 0;
bool    alarm = false;
uint32_t lastTach = 0, lastSample = 0, lastPub = 0, lastDraw = 0;

void IRAM_ATTR fanISR()  { fanPulses++; }
void IRAM_ATTR pumpISR() { pumpPulses++; }

// ===================== HELPERS =====================
uint8_t curveLookup(float t) {
  if (t <= fanCurve[0].t) return fanCurve[0].pct;
  for (int i = 0; i < 4; i++) {
    if (t <= fanCurve[i+1].t) {
      float span = fanCurve[i+1].t - fanCurve[i].t;
      float f = span > 0.01f ? (t - fanCurve[i].t) / span : 0;
      return (uint8_t)(fanCurve[i].pct + f * (fanCurve[i+1].pct - fanCurve[i].pct));
    }
  }
  return fanCurve[4].pct;
}

void applyPWM() {
  uint8_t f = constrain(fanPct,  (uint8_t)FAN_MIN_PCT,  (uint8_t)100);
  uint8_t p = constrain(pumpPct, (uint8_t)PUMP_MIN_PCT, (uint8_t)100);
  ledcWrite(LEDC_FAN_CH,  map(f, 0, 100, 0, 255));
  ledcWrite(LEDC_PUMP_CH, map(p, 0, 100, 0, 255));
}

void saveSettings() {
  prefs.begin("mora", false);
  prefs.putBool("auto", autoMode);
  prefs.putUChar("mf", manualFan);
  prefs.putUChar("mp", manualPump);
  prefs.putUChar("pa", pumpAutoPct);
  prefs.putBytes("curve", fanCurve, sizeof(fanCurve));
  prefs.end();
}

void loadSettings() {
  prefs.begin("mora", true);
  autoMode    = prefs.getBool("auto", true);
  manualFan   = prefs.getUChar("mf", 40);
  manualPump  = prefs.getUChar("mp", 60);
  pumpAutoPct = prefs.getUChar("pa", 60);
  if (prefs.isKey("curve")) prefs.getBytes("curve", fanCurve, sizeof(fanCurve));
  prefs.end();
}

// ===================== WEB UI =====================
const char PAGE[] PROGMEM = R"HTML(<!doctype html><html><head><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1"><title>MO-RA IV</title>
<style>
:root{--bg:#0b0e14;--pnl:#161d29;--edge:#2c3548;--txt:#e8e4da;--sub:#8a93a6;--amb:#ff9f1c;--cy:#38bdf8}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--txt);
font:15px/1.5 ui-monospace,SFMono-Regular,Menlo,monospace;padding:18px}
h1{font-size:16px;letter-spacing:2px;margin:0 0 16px}
.g{display:grid;gap:14px;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));max-width:900px}
.c{background:var(--pnl);border:1px solid var(--edge);border-radius:10px;padding:16px}
.big{font-size:44px;font-weight:700;line-height:1}
.sub{color:var(--sub);font-size:12px;letter-spacing:1px}
.bar{height:10px;background:#0b0e14;border-radius:6px;overflow:hidden;margin:10px 0 6px}
.fill{height:100%;background:var(--amb);transition:width .4s}
.fill.c2{background:var(--cy)}
input[type=range]{width:100%;accent-color:var(--amb)}
input[type=number]{width:64px;background:#0b0e14;color:var(--txt);border:1px solid var(--edge);
border-radius:5px;padding:5px}
button{background:var(--amb);color:#0b0e14;border:0;border-radius:7px;padding:9px 14px;
font-weight:700;cursor:pointer;font-family:inherit}
button.o{background:transparent;color:var(--sub);border:1px solid var(--edge)}
table{width:100%;border-collapse:collapse}td{padding:3px 4px}
.al{color:#ff5252;font-weight:700}
</style></head><body>
<h1>MO-RA IV 600 // CONTROLLER</h1>
<div class=g>
  <div class=c><div class=sub>COOLANT</div><div class=big><span id=t>--</span>&deg;C</div>
    <div id=alarm class=al></div></div>
  <div class=c><div class=sub>FANS</div><div class=big><span id=f>--</span>%</div>
    <div class=bar><div id=fb class=fill style=width:0%></div></div>
    <div class=sub><span id=fr>--</span> RPM</div></div>
  <div class=c><div class=sub>PUMPS</div><div class=big><span id=p>--</span>%</div>
    <div class=bar><div id=pb class="fill c2" style=width:0%></div></div>
    <div class=sub><span id=pr>--</span> RPM</div></div>
  <div class=c><div class=sub>MODE</div>
    <p><button id=ma>AUTO</button> <button id=mm class=o>MANUAL</button></p>
    <div id=man style=display:none>
      <div class=sub>FAN <span id=mfv></span>%</div><input type=range id=mf min=20 max=100>
      <div class=sub>PUMP <span id=mpv></span>%</div><input type=range id=mp min=40 max=100>
    </div>
    <div id=aut><div class=sub>PUMP (auto) <span id=pav></span>%</div>
      <input type=range id=pa min=40 max=100></div>
  </div>
  <div class=c style=grid-column:1/-1><div class=sub>FAN CURVE</div>
    <table id=cv></table><p><button id=sv>SAVE CURVE</button></p></div>
</div>
<script>
let S={};
const $=i=>document.getElementById(i);
function rows(){let h='';for(let i=0;i<5;i++)h+=`<tr><td class=sub>PT${i+1}</td>
<td><input type=number id=ct${i} step=0.5></td><td class=sub>&deg;C &rarr;</td>
<td><input type=number id=cp${i} min=20 max=100></td><td class=sub>%</td></tr>`;$('cv').innerHTML=h;}
rows();
async function poll(){
  const r=await fetch('/api/status');S=await r.json();
  $('t').textContent=S.tempOK?S.temp.toFixed(1):'ERR';
  $('f').textContent=S.fan;$('p').textContent=S.pump;
  $('fb').style.width=S.fan+'%';$('pb').style.width=S.pump+'%';
  $('fr').textContent=S.fanRPM;$('pr').textContent=S.pumpRPM;
  $('alarm').textContent=S.alarm?'!! OVERTEMP — FULL SPEED !!':'';
  $('ma').className=S.auto?'':'o';$('mm').className=S.auto?'o':'';
  $('man').style.display=S.auto?'none':'block';$('aut').style.display=S.auto?'block':'none';
  $('mf').value=S.manualFan;$('mfv').textContent=S.manualFan;
  $('mp').value=S.manualPump;$('mpv').textContent=S.manualPump;
  $('pa').value=S.pumpAuto;$('pav').textContent=S.pumpAuto;
  if(document.activeElement.tagName!=='INPUT')
    S.curve.forEach((c,i)=>{$('ct'+i).value=c.t;$('cp'+i).value=c.pct;});
}
const send=(k,v)=>fetch('/api/set?'+k+'='+v);
$('ma').onclick=()=>send('auto',1).then(poll);
$('mm').onclick=()=>send('auto',0).then(poll);
$('mf').oninput=e=>{$('mfv').textContent=e.target.value;send('fan',e.target.value)};
$('mp').oninput=e=>{$('mpv').textContent=e.target.value;send('pump',e.target.value)};
$('pa').oninput=e=>{$('pav').textContent=e.target.value;send('pumpauto',e.target.value)};
$('sv').onclick=()=>{let q=[];for(let i=0;i<5;i++)q.push($('ct'+i).value+','+$('cp'+i).value);
  fetch('/api/curve?pts='+q.join(';')).then(poll)};
poll();setInterval(poll,1500);
</script></body></html>)HTML";

void handleStatus() {
  String j = "{";
  j += "\"temp\":" + String(tempOK ? coolantC : 0, 1);
  j += ",\"tempOK\":" + String(tempOK ? "true" : "false");
  j += ",\"fan\":" + String(fanPct) + ",\"pump\":" + String(pumpPct);
  j += ",\"fanRPM\":" + String(fanRPM) + ",\"pumpRPM\":" + String(pumpRPM);
  j += ",\"auto\":" + String(autoMode ? "true" : "false");
  j += ",\"manualFan\":" + String(manualFan) + ",\"manualPump\":" + String(manualPump);
  j += ",\"pumpAuto\":" + String(pumpAutoPct);
  j += ",\"alarm\":" + String(alarm ? "true" : "false");
  j += ",\"curve\":[";
  for (int i = 0; i < 5; i++) {
    j += "{\"t\":" + String(fanCurve[i].t, 1) + ",\"pct\":" + String(fanCurve[i].pct) + "}";
    if (i < 4) j += ",";
  }
  j += "]}";
  server.send(200, "application/json", j);
}

void handleSet() {
  if (server.hasArg("auto"))     autoMode   = server.arg("auto").toInt() != 0;
  if (server.hasArg("fan"))      manualFan  = constrain(server.arg("fan").toInt(), FAN_MIN_PCT, 100);
  if (server.hasArg("pump"))     manualPump = constrain(server.arg("pump").toInt(), PUMP_MIN_PCT, 100);
  if (server.hasArg("pumpauto")) pumpAutoPct= constrain(server.arg("pumpauto").toInt(), PUMP_MIN_PCT, 100);
  saveSettings();
  server.send(200, "text/plain", "ok");
}

void handleCurve() {
  if (server.hasArg("pts")) {
    String s = server.arg("pts");
    int idx = 0, start = 0;
    while (idx < 5) {
      int semi = s.indexOf(';', start);
      String seg = (semi < 0) ? s.substring(start) : s.substring(start, semi);
      int comma = seg.indexOf(',');
      if (comma > 0) {
        fanCurve[idx].t   = seg.substring(0, comma).toFloat();
        fanCurve[idx].pct = constrain(seg.substring(comma + 1).toInt(), FAN_MIN_PCT, 100);
      }
      idx++;
      if (semi < 0) break;
      start = semi + 1;
    }
    saveSettings();
  }
  server.send(200, "text/plain", "ok");
}

// ===================== TOUCH UI =====================
struct Btn { int x, y, w, h; const char* label; };
Btn bAuto   = { 12, 186, 90, 44, "AUTO" };
Btn bManual = { 114, 186, 90, 44, "MAN" };
Btn bMinus  = { 216, 186, 44, 44, "-" };
Btn bPlus   = { 266, 186, 44, 44, "+" };

void drawBtn(Btn b, bool on) {
  tft.fillRoundRect(b.x, b.y, b.w, b.h, 6, on ? TFT_ORANGE : 0x2124);
  tft.drawRoundRect(b.x, b.y, b.w, b.h, 6, 0x4A69);
  tft.setTextColor(on ? TFT_BLACK : 0x8C71);
  tft.setTextDatum(MC_DATUM);
  tft.drawString(b.label, b.x + b.w / 2, b.y + b.h / 2, 2);
}

bool hit(Btn b, int x, int y) {
  return x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h;
}

void drawUI() {
  tft.fillScreen(0x0861);
  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(0x8C71);
  tft.drawString("MO-RA IV 600", 12, 8, 2);
  tft.drawString(WiFi.isConnected() ? WiFi.localIP().toString() : "no wifi", 190, 10, 1);
  // panels
  tft.drawRoundRect(8, 32, 148, 66, 6, 0x2C4A);
  tft.drawRoundRect(164, 32, 148, 66, 6, 0x2C4A);
  tft.drawRoundRect(8, 106, 304, 66, 6, 0x2C4A);
}

void drawValues() {
  char buf[24];
  // coolant
  tft.fillRect(12, 36, 140, 58, 0x0861);
  tft.setTextColor(0x8C71); tft.setTextDatum(TL_DATUM);
  tft.drawString("COOLANT", 16, 38, 1);
  tft.setTextColor(alarm ? TFT_RED : TFT_WHITE);
  if (tempOK) snprintf(buf, sizeof buf, "%.1fC", coolantC);
  else        snprintf(buf, sizeof buf, "ERR");
  tft.drawString(buf, 16, 54, 6);

  // fans
  tft.fillRect(168, 36, 140, 58, 0x0861);
  tft.setTextColor(0x8C71); tft.drawString("FANS", 172, 38, 1);
  snprintf(buf, sizeof buf, "%d%%", fanPct);
  tft.setTextColor(TFT_ORANGE); tft.drawString(buf, 172, 52, 6);
  snprintf(buf, sizeof buf, "%u RPM", fanRPM);
  tft.setTextColor(0x8C71); tft.drawString(buf, 172, 84, 1);

  // pumps + mode row
  tft.fillRect(12, 110, 296, 58, 0x0861);
  tft.setTextColor(0x8C71); tft.drawString("PUMPS", 16, 112, 1);
  snprintf(buf, sizeof buf, "%d%%", pumpPct);
  tft.setTextColor(0x3E7F); tft.drawString(buf, 16, 126, 6);
  snprintf(buf, sizeof buf, "%u RPM", pumpRPM);
  tft.setTextColor(0x8C71); tft.drawString(buf, 120, 150, 1);
  tft.setTextColor(alarm ? TFT_RED : 0x8C71);
  tft.drawString(alarm ? "OVERTEMP - FULL SPEED" : (autoMode ? "curve control" : "manual"),
                 120, 122, 2);

  drawBtn(bAuto,  autoMode);
  drawBtn(bManual, !autoMode);
  drawBtn(bMinus, false);
  drawBtn(bPlus,  false);
}

void handleTouch() {
  if (!ts.touched()) return;
  TS_Point p = ts.getPoint();
  int x = map(p.x, TS_MINX, TS_MAXX, 0, 320);
  int y = map(p.y, TS_MINY, TS_MAXY, 0, 240);
  x = constrain(x, 0, 319); y = constrain(y, 0, 239);

  bool changed = false;
  if (hit(bAuto, x, y))        { autoMode = true;  changed = true; }
  else if (hit(bManual, x, y)) { autoMode = false; changed = true; }
  else if (hit(bMinus, x, y)) {
    if (autoMode) pumpAutoPct = max(PUMP_MIN_PCT, pumpAutoPct - 5);
    else          manualFan   = max(FAN_MIN_PCT,  manualFan - 5);
    changed = true;
  } else if (hit(bPlus, x, y)) {
    if (autoMode) pumpAutoPct = min(100, pumpAutoPct + 5);
    else          manualFan   = min(100, manualFan + 5);
    changed = true;
  }
  if (changed) { saveSettings(); drawValues(); delay(180); }
}

// ===================== MQTT =====================
void mqttPub() {
  if (!MQTT_HOST[0] || !mqtt.connected()) return;
  char buf[200];
  snprintf(buf, sizeof buf,
    "{\"temp\":%.1f,\"fan\":%d,\"pump\":%d,\"fanRPM\":%u,\"pumpRPM\":%u,"
    "\"mode\":\"%s\",\"alarm\":%s}",
    tempOK ? coolantC : 0.0f, fanPct, pumpPct, fanRPM, pumpRPM,
    autoMode ? "auto" : "manual", alarm ? "true" : "false");
  mqtt.publish("mora/status", buf);
}

// ===================== SETUP =====================
void setup() {
  Serial.begin(115200);
  pinMode(PIN_BACKLIGHT, OUTPUT); digitalWrite(PIN_BACKLIGHT, HIGH);
  pinMode(PIN_BUZZER, OUTPUT);

  // PWM out — start at 100% so the MoRa is cooling from the first millisecond
  ledcSetup(LEDC_FAN_CH,  PWM_FREQ, PWM_RES);
  ledcSetup(LEDC_PUMP_CH, PWM_FREQ, PWM_RES);
  ledcAttachPin(PIN_FAN_PWM,  LEDC_FAN_CH);
  ledcAttachPin(PIN_PUMP_PWM, LEDC_PUMP_CH);
  ledcWrite(LEDC_FAN_CH, 255); ledcWrite(LEDC_PUMP_CH, 255);

  // tach in
  pinMode(PIN_FAN_TACH, INPUT);              // GPIO35: external 10k pull-up REQUIRED
  pinMode(PIN_PUMP_TACH, INPUT_PULLUP);
  attachInterrupt(PIN_FAN_TACH,  fanISR,  FALLING);
  attachInterrupt(PIN_PUMP_TACH, pumpISR, FALLING);

  sensors.begin();
  sensors.setResolution(11);
  loadSettings();

  tft.init(); tft.setRotation(1);
  touchSPI.begin(25, 39, 32, T_CS);
  ts.begin(touchSPI); ts.setRotation(1);
  drawUI();

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  for (int i = 0; i < 40 && WiFi.status() != WL_CONNECTED; i++) delay(250);

  server.on("/", []() { server.send_P(200, "text/html", PAGE); });
  server.on("/api/status", handleStatus);
  server.on("/api/set", handleSet);
  server.on("/api/curve", handleCurve);
  server.begin();

  if (MQTT_HOST[0]) mqtt.setServer(MQTT_HOST, MQTT_PORT);

  esp_task_wdt_init(15, true);   // hang -> reboot -> PWM idles -> fans 100%
  esp_task_wdt_add(NULL);
  drawUI(); drawValues();
}

// ===================== LOOP =====================
void loop() {
  esp_task_wdt_reset();
  server.handleClient();
  handleTouch();

  if (MQTT_HOST[0] && !mqtt.connected() && millis() % 5000 < 20) mqtt.connect(MQTT_ID);
  if (mqtt.connected()) mqtt.loop();

  uint32_t now = millis();

  // --- tach: count pulses over 1s. 2 pulses/rev for fans and D5s. ---
  if (now - lastTach >= 1000) {
    noInterrupts();
    uint32_t f = fanPulses, p = pumpPulses;
    fanPulses = 0; pumpPulses = 0;
    interrupts();
    fanRPM  = (uint16_t)(f * 30);   // pulses * 60 / 2
    pumpRPM = (uint16_t)(p * 30);
    lastTach = now;
  }

  // --- temp + control, twice a second ---
  if (now - lastSample >= 500) {
    lastSample = now;
    sensors.requestTemperatures();
    float t = sensors.getTempCByIndex(0);
    tempOK = (t > -50.0f && t < 100.0f);   // DEVICE_DISCONNECTED = -127
    if (tempOK) coolantC = t;

    alarm = tempOK && coolantC >= TEMP_ALARM_C;

    if (!tempOK) {
      // sensor gone: assume the worst, cool at full
      fanPct = TEMP_SENSOR_FAIL_PCT;
      pumpPct = 100;
    } else if (alarm) {
      fanPct = 100; pumpPct = 100;
    } else if (autoMode) {
      fanPct  = curveLookup(coolantC);
      pumpPct = pumpAutoPct;
    } else {
      fanPct  = manualFan;
      pumpPct = manualPump;
    }
    applyPWM();

    digitalWrite(PIN_BUZZER, (alarm && (now / 500) % 2) ? HIGH : LOW);
  }

  if (now - lastDraw >= 1000) { drawValues(); lastDraw = now; }
  if (now - lastPub  >= 5000) { mqttPub();    lastPub  = now; }
}
